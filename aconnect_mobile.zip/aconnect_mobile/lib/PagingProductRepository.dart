class PagingProductRepository {
  List<int> id = new List();
  List<String> locationDescription = new List();
  List<String> customerName = new List();
  List<String> itemDescription = new List();
  List<String> createdDateFormat = new List();
  List<String> flag = new List();
}
