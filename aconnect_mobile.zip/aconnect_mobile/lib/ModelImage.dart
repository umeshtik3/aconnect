class ModelImage {
  String image;
  String name;
  String brief;
  int counter = -1;
}
