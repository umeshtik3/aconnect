class MyStrings {
  static const String lorem_ipsum =
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam efficitur ipsum in placerat molestie.  Fusce quis mauris a enim sollicitudin"
      "\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam efficitur ipsum in placerat molestie.  Fusce quis mauris a enim sollicitudin";

  static const String middle_lorem_ipsum =
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam efficitur ipsum in placerat molestie.  Fusce quis mauris a enim sollicitudin";

  static const String short_lorem_ipsum =
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";

  static const String medium_lorem_ipsum =
      "Quisque imperdiet nunc at massa dictum volutpat. Etiam id orci ipsum. Integer id ex dignissim";

  static const String long_lorem_ipsum =
      "Duis tellus metus, elementum a lectus id, aliquet interdum mauris. Nam bibendum efficitur sollicitudin. Proin eleifend libero velit, "
      "\n\nNulla id lectus metus. Maecenas a lorem in odio auctor facilisis non vitae nunc. Sed malesuada volutpat massa. Praesent sit amet lacinia augue, mollis tempor dolor.";

  static const String long_lorem_ipsum_2 =
      "Vivamus porttitor, erat at aliquam mollis, risus ligula suscipit metus, id semper nisi dui lacinia leo. Praesent at feugiat sem. Vivamus consectetur arcu sit amet metus efficitur dapibus. Sed metus ligula, efficitur quis finibus nec, pellentesque nec nulla. Nunc nec magna iaculis turpis vehicula condimentum id lobortis lectus."
      "\n\nQuisque augue diam, convallis nec mollis in, placerat nec elit. Aliquam non erat tristique, consequat tortor ultricies, sodales erat. Aliquam quis enim eu nulla facilisis sollicitudin eu mollis mauris. Donec ornare urna non libero volutpat tempus. Mauris elementum egestas ex, a laoreet urna. Ut a magna mattis, sodales massa a, blandit justo";

  static const String invoice_address =
      "Terry M Smith\n(904) 246-1297\n207 Cherry St, Neptune Beach, FL, 32266";

  static const String very_long_lorem_ipsum1 =
      "ALOK Technology Incubation Centre.";
  static const String very_long_lorem_ipsum =
      "Alok also has its own innovation lab, Alok Technology Incubation Centre (ATIC) based in Delhi which offers a state-of-the-art facility with a wide array of testing equipment required to drive innovation in the masterbatch industry."
      "\n\n At this lab, Alok creates customized solutions that address the needs of our customers and partners. We also invite and encourage academia to collaborate and co-curate solutions to make plastics safer, sustainable and affordable."
      "\n\nWork done at ATIC is appreciated in the Plastics Sector. ATIC has won 2 National Awards for Innovation by Govt. of India & very recently coffered with prestigious Golden Peacock for Eco-Innovation Award 2019."
      "\n\nATIC is equipped with advanced testing facilities related to Material Characterization, Destructive & Non Destructive Product Testing & Failure Analysis";

  static const String gdpr_privacy_policy =
      "By using this App, you agree to the Terms-Conditions "
      "Cookies-Policy and Privacy-Policy and consent to having your personal data, behavior transferred and processed outside EU.";
}
