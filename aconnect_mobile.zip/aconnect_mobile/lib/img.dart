class Img {
  static String get(String name) {
    return 'assets/images/' + name;
  }
}
