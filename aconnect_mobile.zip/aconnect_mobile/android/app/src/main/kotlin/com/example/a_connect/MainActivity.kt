package com.example.a_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
